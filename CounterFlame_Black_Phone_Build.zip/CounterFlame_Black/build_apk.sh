#!/usr/bin/env sh
set -eu
gradle assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
