# No custom keep rules are required for this standalone UI project.
