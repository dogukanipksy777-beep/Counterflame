package com.cfmod;

/**
 * Safe placeholder bridge.
 * This project does not load or modify a game's Unity/IL2CPP runtime.
 */
public final class UnityBridge {
    private UnityBridge() {}

    public static boolean isUnityRuntimeAvailable() {
        return false;
    }

    public static String getStatus() {
        return "Unity bağlantısı yapılandırılmadı.";
    }
}
