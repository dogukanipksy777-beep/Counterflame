package com.cfmod;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private final String[] options = {
        "God Mode", "Invisibility", "Fly Modu", "Noclip", "WallBang",
        "Silent Aim", "ESP", "Charms", "Auto Win", "Skin Changer (Tüm Skinler)",
        "No Recoil", "No Spread", "Rapid Fire", "Infinite Ammo",
        "Hızlı Koşma", "Yüksek Zıplama"
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createBubble();
        createPanel();
        try { windowManager.addView(bubble, bubbleParams); }
        catch (Exception e) { stopSelf(); }
    }

    private void createBubble() {
        TextView button = new TextView(this);
        button.setText("MOD");
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(15), dp(12), dp(15), dp(12));
        button.setBackground(round(Color.rgb(24, 24, 24), dp(18), Color.rgb(95, 95, 95)));
        bubble = button;

        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.END;
        bubbleParams.x = dp(18);
        bubbleParams.y = dp(110);

        button.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = bubbleParams.x; startY = bubbleParams.y;
                    downX = event.getRawX(); downY = event.getRawY(); moved = false;
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int) (event.getRawX() - downX);
                    int dy = (int) (event.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved = true;
                    if (moved) {
                        bubbleParams.x = Math.max(0, startX - dx);
                        bubbleParams.y = Math.max(0, startY + dy);
                        try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                    }
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel();
                    return true;
                }
                return true;
            }
        });
    }

    private void createPanel() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(round(Color.rgb(12, 12, 12), dp(16), Color.rgb(65, 65, 65)));

        TextView heading = new TextView(this);
        heading.setText("COUNTERFLAME  /  MENU");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(16);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setPadding(0, 0, 0, dp(12));
        card.addView(heading);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        for (String option : options) {
            CheckBox check = new CheckBox(this);
            check.setText(option);
            check.setTextColor(Color.WHITE);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.LTGRAY));
            check.setTextSize(14);
            check.setPadding(0, dp(3), 0, dp(3));
            check.setChecked(getSharedPreferences("menu", MODE_PRIVATE).getBoolean(option, false));
            check.setOnCheckedChangeListener((button, checked) ->
                    getSharedPreferences("menu", MODE_PRIVATE).edit().putBoolean(option, checked).apply());
            content.addView(check);
        }

        TextView speedLabel = new TextView(this);
        speedLabel.setTextColor(Color.WHITE);
        speedLabel.setTextSize(14);
        int savedSpeed = getSharedPreferences("menu", MODE_PRIVATE).getInt("speed", 1);
        speedLabel.setText("Hız göstergesi: " + savedSpeed + "x");
        content.addView(speedLabel);

        SeekBar speed = new SeekBar(this);
        speed.setMax(9);
        speed.setProgress(Math.max(0, Math.min(9, savedSpeed - 1)));
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = progress + 1;
                speedLabel.setText("Hız göstergesi: " + value + "x");
                if (fromUser) getSharedPreferences("menu", MODE_PRIVATE).edit().putInt("speed", value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        content.addView(speed);
        scroll.addView(content);
        card.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView close = new TextView(this);
        close.setText("KAPAT");
        close.setTextColor(Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setPadding(0, dp(12), 0, dp(4));
        close.setOnClickListener(v -> togglePanel());
        card.addView(close);

        panel = card;
        panelParams = new WindowManager.LayoutParams(
                Math.min(dp(330), getResources().getDisplayMetrics().widthPixels - dp(28)),
                Math.min(dp(520), getResources().getDisplayMetrics().heightPixels - dp(100)),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
    }

    private void togglePanel() {
        try {
            if (panel.getParent() == null) windowManager.addView(panel, panelParams);
            else windowManager.removeView(panel);
        } catch (Exception ignored) {}
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        try { if (panel != null && panel.getParent() != null) windowManager.removeView(panel); } catch (Exception ignored) {}
        try { if (bubble != null && bubble.getParent() != null) windowManager.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
