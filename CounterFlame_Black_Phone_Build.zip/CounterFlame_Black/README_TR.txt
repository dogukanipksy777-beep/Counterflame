COUNTERFLAME BLACK - Android Studio projesi

Özellikler:
- Siyah temalı ana ekran
- İzin verildiğinde ekranda yüzen MOD düğmesi
- Açılır/kapanır kaydırılabilir menü
- Menü seçenekleri ve hız kaydırıcısı için yerel ayar kaydı
- MOD düğmesini ekranda sürükleyebilme

ÖNEMLİ SINIRLAR:
- Menüdeki seçenekler yalnızca arayüz/yerel tercih örnekleridir. Bir oyuna bağlanmaz,
  oyun belleğini değiştirmez ve oyun içi avantaj sağlamaz.
- Orijinal gönderilen kaynak dosyalar original_sources/ altında korunur.
- Unity/IL2CPP .dll/.so dosyaları yüklenmediği için gerçek Unity oyunu entegrasyonu
  veya oyunla çalışan bir APK üretilemez.
- Bu proje Android uygulamasıdır; APK üretmek için Android Studio ve JDK 17 gerekir.

Derleme:
1. Android Studio ile bu klasörü aç.
2. Gradle senkronizasyonunun bitmesini bekle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
   Alternatif: terminalde gradle assembleDebug çalıştır.
4. APK: app/build/outputs/apk/debug/app-debug.apk

İlk açılış:
1. Uygulamada "Yüzen menüyü başlat" düğmesine bas.
2. Android'in "Diğer uygulamaların üzerinde göster" iznini ver.
3. Uygulamaya dönüp düğmeye yeniden bas.
4. Ekrandaki MOD düğmesine dokunarak menüyü aç/kapat.

TELEFONDAN APK DERLEME (GitHub Actions)
1. Bu ZIP'i telefonuna indir ve arşiv uygulamasıyla çıkar.
2. GitHub hesabınla github.com'a girip yeni, boş bir repository oluştur.
3. Çıkarılan CounterFlame_Black klasörünün içindeki dosyaları repository'nin kök dizinine yükle. .github klasörünü de mutlaka yükle.
4. Repository'de Actions sekmesine gir. "Android APK Build" iş akışını seçip "Run workflow" düğmesine bas.
5. İşlem tamamlanınca çalışmanın sayfasındaki Artifacts bölümünden CounterFlame-debug-apk dosyasını indir.
Not: Bu yöntem GitHub'ın bulut bilgisayarlarını kullanır. APK yalnızca bu projedeki siyah temalı, sürüklenebilir MOD menüsü ve yerel ayar arayüzüdür; oyun içine müdahale veya hile işlevi içermez. GitHub arayüzündeki dosya yükleme adımları telefonda biraz zahmetli olabilir.
