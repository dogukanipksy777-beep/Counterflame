package com.cfmod;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {

    private View overlay;
    private WindowManager wm;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        BuildOverlay();
    }

    private void BuildOverlay() {
        FrameLayout root = new FrameLayout(this);

        TextView btn = new TextView(this);
        btn.setText("MOD");
        btn.setTextColor(0xFFFFFFFF);
        btn.setBackgroundColor(0xCCFF3300);
        btn.setPadding(30, 30, 30, 30);
        btn.setTextSize(18f);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = 50; lp.rightMargin = 40;
        root.addView(btn, lp);

        final LinearLayout menu = BuildMenu();
        menu.setVisibility(View.GONE);
        root.addView(menu, new FrameLayout.LayoutParams(600, 900, Gravity.CENTER));

        btn.setOnClickListener(v ->
            menu.setVisibility(menu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));

        overlay = root;

        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                  | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type, flags, PixelFormat.TRANSLUCENT);

        try { wm.addView(overlay, params); }
        catch (Exception e) { e.printStackTrace(); }
    }

    private LinearLayout BuildMenu() {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setBackgroundColor(0xEE000000);
        ll.setPadding(20, 20, 20, 20);

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        String[] items = {
            "God Mode", "Invisibility", "Fly Modu", "Noclip",
            "WallBang", "Silent Aim", "ESP", "Charms",
            "Auto Win", "Skin Changer (Tüm Skinler)",
            "No Recoil", "No Spread", "Rapid Fire", "Infinite Ammo",
            "Hızlı Koşma", "Yüksek Zıplama"
        };

        for (String s : items) {
            CheckBox cb = new CheckBox(this);
            cb.setText(s);
            cb.setTextColor(0xFFFFFFFF);
            cb.setTextSize(16f);
            col.addView(cb);
        }

        TextView speedLbl = new TextView(this);
        speedLbl.setText("Hız: 1x");
        speedLbl.setTextColor(0xFF00FF00);
        col.addView(speedLbl);

        SeekBar speed = new SeekBar(this);
        speed.setMax(99);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                speedLbl.setText("Hız: " + (p + 1) + "x");
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        col.addView(speed);

        sv.addView(col);
        ll.addView(sv);
        return ll;
    }

    @Override
    public void onDestroy() {
        if (overlay != null && wm != null)
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        super.onDestroy();
    }
}