using System;
using System.Collections.Generic;
using UnityEngine;

public class UnityMainThreadDispatcher : MonoBehaviour
{
    private static readonly Queue<Action> Q = new Queue<Action>();
    private static UnityMainThreadDispatcher instance;

    public static void Ensure()
    {
        if (instance != null) return;
        var go = new GameObject("MainThreadDispatcher");
        DontDestroyOnLoad(go);
        instance = go.AddComponent<UnityMainThreadDispatcher>();
    }

    public static void Enqueue(Action action)
    {
        if (action == null) return;
        lock (Q) Q.Enqueue(action);
    }

    private void Update()
    {
        lock (Q)
        {
            while (Q.Count > 0)
            {
                try { Q.Dequeue()?.Invoke(); }
                catch (Exception e) { Debug.LogError(e); }
            }
        }
    }
}
