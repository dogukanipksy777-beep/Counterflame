// Safe UI settings model only. No game hooks or gameplay modifications.
public class Cheats
{
    public bool GodMode, Invisibility, Fly, Noclip, WallBang, SilentAim;
    public bool ESP, Charms, AutoWin, SkinChanger, NoRecoil, NoSpread;
    public bool RapidFire, InfiniteAmmo, SpeedHack, HighJump;
    public float SpeedMultiplier = 1f;
    public float JumpMultiplier = 1f;
}
