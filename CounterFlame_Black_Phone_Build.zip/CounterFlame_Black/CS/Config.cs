using System;
using System.IO;
using UnityEngine;

[Serializable]
public class ConfigData
{
    public bool godMode, invisibility, fly, noclip, wallBang, silentAim;
    public bool esp, charms, autoWin, skinChanger, noRecoil, noSpread;
    public bool rapidFire, infiniteAmmo, speedHack, highJump;
    public float speedMultiplier = 1f;
    public float jumpMultiplier = 1f;
}

public static class Config
{
    private static string ConfigPath =>
        Path.Combine(Application.persistentDataPath, "CFMod_config.json");

    public static void Save(Cheats c)
    {
        if (c == null) return;
        var data = new ConfigData {
            godMode = c.GodMode, invisibility = c.Invisibility,
            fly = c.Fly, noclip = c.Noclip, wallBang = c.WallBang,
            silentAim = c.SilentAim, esp = c.ESP, charms = c.Charms,
            autoWin = c.AutoWin, skinChanger = c.SkinChanger,
            noRecoil = c.NoRecoil, noSpread = c.NoSpread,
            rapidFire = c.RapidFire, infiniteAmmo = c.InfiniteAmmo,
            speedHack = c.SpeedHack, highJump = c.HighJump,
            speedMultiplier = c.SpeedMultiplier, jumpMultiplier = c.JumpMultiplier
        };
        File.WriteAllText(ConfigPath, JsonUtility.ToJson(data, true));
    }

    public static void Load(Cheats c)
    {
        if (c == null || !File.Exists(ConfigPath)) return;
        try
        {
            var data = JsonUtility.FromJson<ConfigData>(File.ReadAllText(ConfigPath));
            if (data == null) return;
            c.GodMode = data.godMode; c.Invisibility = data.invisibility;
            c.Fly = data.fly; c.Noclip = data.noclip; c.WallBang = data.wallBang;
            c.SilentAim = data.silentAim; c.ESP = data.esp; c.Charms = data.charms;
            c.AutoWin = data.autoWin; c.SkinChanger = data.skinChanger;
            c.NoRecoil = data.noRecoil; c.NoSpread = data.noSpread;
            c.RapidFire = data.rapidFire; c.InfiniteAmmo = data.infiniteAmmo;
            c.SpeedHack = data.speedHack; c.HighJump = data.highJump;
            c.SpeedMultiplier = data.speedMultiplier; c.JumpMultiplier = data.jumpMultiplier;
        }
        catch (Exception e) { Debug.LogWarning("Config load failed: " + e.Message); }
    }
}
