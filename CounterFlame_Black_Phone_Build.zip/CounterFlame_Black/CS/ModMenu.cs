using UnityEngine;

// Standalone Unity UI preview only. It does not connect to a game or alter gameplay.
public class ModMenu : MonoBehaviour
{
    public static ModMenu Instance { get; private set; }
    private bool visible = true;
    private Rect window = new Rect(20, 80, 360, 520);
    private Vector2 scroll;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnGUI()
    {
        if (GUI.Button(new Rect(12, 12, 76, 38), "MOD")) visible = !visible;
        if (!visible) return;
        window = GUI.Window(9271, window, DrawWindow, "COUNTERFLAME / BLACK");
    }

    private void DrawWindow(int id)
    {
        scroll = GUILayout.BeginScrollView(scroll);
        GUILayout.Label("Bu seçenekler yalnızca arayüz örneğidir.");
        GUILayout.Toggle(false, "God Mode (UI demo)");
        GUILayout.Toggle(false, "Invisibility (UI demo)");
        GUILayout.Toggle(false, "Fly Modu (UI demo)");
        GUILayout.Toggle(false, "Noclip (UI demo)");
        GUILayout.Toggle(false, "WallBang (UI demo)");
        GUILayout.Toggle(false, "Silent Aim (UI demo)");
        GUILayout.Toggle(false, "ESP (UI demo)");
        GUILayout.Toggle(false, "Charms (UI demo)");
        GUILayout.Toggle(false, "Auto Win (UI demo)");
        GUILayout.Toggle(false, "Skin Changer (UI demo)");
        GUILayout.Toggle(false, "No Recoil (UI demo)");
        GUILayout.Toggle(false, "No Spread (UI demo)");
        GUILayout.Toggle(false, "Rapid Fire (UI demo)");
        GUILayout.Toggle(false, "Infinite Ammo (UI demo)");
        GUILayout.EndScrollView();
        GUI.DragWindow(new Rect(0, 0, 10000, 24));
    }
}
